package com.example.controldefichaje;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class ProfesorHomeFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profesor_home, container, false);

        view.findViewById(R.id.imgProfesorHome).setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), ActivityProfesor.class);
            startActivity(intent);
        });

        return view;
    }
}
