package com.example.controldefichaje;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityAdmin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        // Botón para ir a la lista de usuarios
        Button btnViewUsers = findViewById(R.id.btnViewUsers);
        btnViewUsers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ActivityAdmin.this, ActivityUsuarios.class);
                startActivity(intent);
            }
        });

        // Botón para modificar usuarios
        Button btnModifyUser = findViewById(R.id.btnAddUser);
        btnModifyUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ActivityAdmin.this, ActivityModifyUser.class);
                startActivity(intent);
            }
        });
    }
}
