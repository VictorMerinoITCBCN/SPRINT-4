package com.example.controldefichaje;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityProfesor extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profesor);

        // Botón para modificar horario
        Button btnModifySchedule = findViewById(R.id.btnViewSchedule);
        btnModifySchedule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ActivityProfesor.this, ActivityModifyHorario.class);
                startActivity(intent);
            }
        });

        // Botón para pasar lista
        Button btnTakeAttendance = findViewById(R.id.btnTakeAttendance);
        btnTakeAttendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ActivityProfesor.this, ActivityLista.class);
                startActivity(intent);
            }
        });
    }
}
